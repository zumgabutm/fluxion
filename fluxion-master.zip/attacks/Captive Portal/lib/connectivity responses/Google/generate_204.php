<?php
	header("HTTP/1.0 204 No Content");
